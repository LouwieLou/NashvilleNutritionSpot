// use config variables here to set the database access username/password

const config = {
  db: { /* don't expose password or any sensitive info, done only for demo */
    host: 'freedb.tech',
    user: 'freedbtech_reganskandalukelouis',
    password: 'nashvillenutritionspot',
    database: 'freedbtech_nashvilleNutritionMenu',
  },
};


module.exports = config;